package ru.manzilin.homework.h_14;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class New {
}
