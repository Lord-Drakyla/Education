package ru.manzilin.homework.h_09.Task1;

abstract class Animal {
    int distance;
    int speed;
    int direction;
    String name;

    abstract void getName();
    abstract String say() ;
    }


