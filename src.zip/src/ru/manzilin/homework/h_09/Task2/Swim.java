package ru.manzilin.homework.h_09.Task2;

public interface Swim {
    String PLACE = "Liquid";
    void canSwim();
}
