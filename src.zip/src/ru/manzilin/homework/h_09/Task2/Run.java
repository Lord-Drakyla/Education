package ru.manzilin.homework.h_09.Task2;

public interface Run {
    String PLACE = "Ground";
    void canRun();
    void canWalk();
}
