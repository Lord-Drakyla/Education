package ru.manzilin.homework.h_09.Task2;

public interface Fly {
    String PLACE = "Sky";
    void canFly();

}
