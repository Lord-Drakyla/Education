package ru.manzilin.homework.h_13.Task2.Food;



public class Banane extends Food {
    public Banane(String typeFood) {
        super(typeFood);
    }
}
