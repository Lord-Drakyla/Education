package ru.manzilin.homework.h_13.Task2.Food;



public class Burger extends Food {
    public Burger(String typeFood) {
        super(typeFood);
    }
}
