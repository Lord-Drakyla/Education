package ru.manzilin.homework.h_13.Task2.Food;

public class Milk extends ru.manzilin.homework.h_13.Task2.Food.Food {

    public Milk(String typeFood) {
        super(typeFood);
    }
}
