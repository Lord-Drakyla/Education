package ru.manzilin.homework.h_13.Task2;



abstract class Homo  {
    final String propertyMain = "Sapiens";
    String name;


    public Homo(String name) {
        this.name = name;

    }
}
