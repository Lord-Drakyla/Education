package ru.manzilin.homework.h_13.Task2;

public class FoodNegativeException extends RuntimeException {
    public FoodNegativeException(String message) {
        super(message);
    }

}
