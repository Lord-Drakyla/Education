package ru.manzilin.homework.h_13.Task1.Exceptions;

public class MoneyNotEnoughExceprion extends VenMachineExceprion {
    public MoneyNotEnoughExceprion(String message) {
        super(message);
    }
}
