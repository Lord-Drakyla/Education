package ru.manzilin.homework.h_13.Task1.Exceptions;

public class VenMachineExceprion extends RuntimeException{
    public VenMachineExceprion(String message) {
        super(message);
    }
}
