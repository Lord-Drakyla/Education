package ru.manzilin.homework.h_13.Task1.Exceptions;

public class GoodsExceprion extends VenMachineExceprion {
    public GoodsExceprion(String message) {
        super(message);
    }
}
