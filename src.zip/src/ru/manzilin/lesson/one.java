package ru.manzilin.lesson;

import java.io.*;

public class one {
    public static void main(String[] args) {

    }
    private static void addAnimal(){
        Animal animal = new Cat();
    }
    }


